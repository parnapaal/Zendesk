import unittest

class TestOrganization(unittest.TestCase):
    
    #get the notes associated with this organization
    def areTheyActive(self):
        
    def defaultPrioritySetToNormal():
        
    def setTheOrganizationIdFromTheRequester():
        
    def groupIdIsReceivedFromAsignee():
        
    def ifSubscriptionIsEmptyCheckTags():
        
    
    
if __name__ == '__main__':
    unittest.main()
