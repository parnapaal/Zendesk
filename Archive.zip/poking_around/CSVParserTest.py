import unittest

class TestCSVParser(unittest.TestCase):
    
    def labelfilesToParseWithString():
        
    def openOurFileSets(): 
        
    def cleanUnecessaryCharactersFromNotesOrg():
        
    def cleanUnecessaryCharactersFromNotesUsers():
        
    def cleanUnecessaryCharactersFromNotesTickets():
        
    def duplicateUsersAreRemoved():
        
    
    
        

    
if __name__ == '__main__':
    unittest.main()