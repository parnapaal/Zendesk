class User:
    #instantiate our organnization with the necessary into
    def __init__(self, userName, email, organizationId, role, isActive, isShared, notes, group, emp_id, promotionCode, subcription, tags):
        self.userName = userName
        self.email = email
        self.organizationId = organizationId
        self.role = role
        self.isActive = isActive
        self.notes = notes
        self.group = group
        self.subscription = subscription
        self.empId = empId
        self.promotionCode = promotionCode
        self.tags = tags
        
            
    #get organization name
    def getUserName(self):
    
    #get the domain name(s) associated with this organizatoin
    def getEmail(self):
    
    #get the details associated with this organization
    def getOrgId(self):
    
    #get the notes associated with this organization
    def getRole(self):
        
    #get the notes associated with this organization
    def areTheyActive(self):
        
    #get the region this organization is found in
    def getNotes(self):
    
    #get any and all tags
    def getGroups(self):
        
    #get any and all tags
    def getDefaultGroup(self):
        
    def getSubscription():
        
    #get any and all tags
    def getEmpId(self):
        
    #get any and all tags
    def getPromotionCode(self):
        
    #get any and all tags
    def getTags(self):
     
    #turn this into a json entry
    def toJson(self):
     
    #return the json entry
    def getJson(self)
        
        
        