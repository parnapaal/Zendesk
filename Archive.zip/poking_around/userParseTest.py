def fileOpens()

def pandasWorks()

def parsingOutNewLinesInTheRightPlaces()
#check line 2

def emailsStayIntact()

def parseDomainNamesCorrectly()

def addTagToWeirdOrgs()
#might take this out

def entryInstanceMade()

def moreThanOneOrgFound()



