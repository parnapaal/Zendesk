import unittest

class TestOrganization(unittest.TestCase):
    
    #instantiate an object correctly within organization
    def testInstantiation(self):
        
    def getOrgFeatures():
        
    def getAllOfTheDomains():
        
    def getJsonOfOrg():
        

    
if __name__ == '__main__':
    unittest.main()