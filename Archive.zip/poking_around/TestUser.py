import unittest

class TestUser(unittest.TestCase):
    
    #instantiate an object correctly within organization
    def testInstantiation(self):
        
    #def getOrgFeatures():
        
    def adminIsGivenAGroupId():
        
    def agentIsGivenAGroupID():
      
    def endUserHasNoGroup():
        
    def AgentIsShared():
        
    def userIsShared():
        
    def customGroupIsSet(): 
        
    def defaultGroupSetForAgentWithOneGroup():
    
    def defaultGroupSetForAgentWithMoreGroups():
        
    def endUsersAreRestrictedAgents():
        
    def subscriptionOptionGold():
        
    def subscriptionOptionSilver():
        
    def subscriptionOptionOther():
        
    def getJsonOfOrg():
        
    def extraMembershipsToAddToGroups():
        
    def extraMembershipsToAddToOrgs(): 
        
    
if __name__ == '__main__':
    unittest.main()