def main():
    print "Hello, world!"
    
def getFromZendesk():
    
def putInZendesk():
    
def deleteFromZendesk():
    
def importOrgs():
    
def callZenDeskForOrgIds():

def importUsers():
    
def importTickets():
    
def mergeSimilarData():
    
def giveUsersOrgId():
    
def giveUsersOrgName():
    
def giveTicketsOrgId():
    
def giveTicketsGroupId(): 
    
def importTickets():
    
    
    

if __name__ == '__main__':
    main()