class Ticket:
    #instantiate our organnization with the necessary into
    def __init__(self, asigneeId, createdAt, subject, description, status, submitterId, requesterId, updatedAt, dueAt, about, businessName, dept, empId, productInfo, startDate, subscription, tags, requesterOrgId, AsigneeGroupId):
        
        self.asigneeId = asigneeId
        self.createdAt = createdAt
        self.subject = subject
        self.description = description
        self.status = status
        self.submitterId = submitterId
        self.requesterId = requesterId
        self.updatedAt = updatedAt
        self.dueAt = dueAt
        self.businessName = businessName
        self.dept = dept
        self.empId = empId
        self.productInfo = productInfo
        self.startDate = startDate
        self.subscription = subscription
        self.tags = tags
        
        self.requesterOrgId = requesterOrgId
        self.AsigneeGroupId = AsigneeGroupId
                  
    #get organization name
    def getAsigneeId(self):
        
    def getAsigneeGroupId(self)
    
    #get the domain name(s) associated with this organizatoin
    def getCreatedAt(self):
    
    #get the details associated with this organization
    def getSubject(self):
    
    #get the notes associated with this organization
    def getDescription(self):
        
        
    #get the region this organization is found in
    def getStatus(self):
    
    #get any and all tags
    def getSubmitterId(self):
        
    def getRequesterId(self):
        
    def getRequesterOrdId(self):
        
    #get any and all tags
    def getUpdatedAt(self):
        
    def getDueAt():
        
    #get any and all tags
    def getBusinessName(self):
        
    #get any and all tags
    def getDept(self):
        
    #get any and all tags
    #who's emp should this be? 
    #def getEmpIdFrom(self):
    
    def getProductInfo(self):
        
    def getStartDate(self):
        
    def getSubscription(self):
        
    def getTags(self):
     
    #turn this into a json entry
    def toJson(self):
     
    #return the json entry
    def getJson(self)
        
    
        